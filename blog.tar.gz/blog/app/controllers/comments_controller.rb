class CommentsController < ApplicationController

end
