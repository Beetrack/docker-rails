class Comment < ActiveRecord::Base
end
