Rails.application.routes.draw do
  resources :posts
  resources :comments
end
